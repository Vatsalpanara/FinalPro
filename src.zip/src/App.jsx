import React from 'react'
import {BrowserRouter, Route, Routes} from 'react-router-dom'
import Login from './Component/Login'
import SignUp from './Component/SignUp'
import Home from './Component/Home'
import Gauth from './Component/Gauth'


function App() {
  // const [count, setCount] = useState("")
  return (
    <>

<BrowserRouter>
<Routes>
  <Route path='/' Component={Login}></Route>
  <Route path='/signup' Component={SignUp}></Route>
  <Route path='/home' Component={Home}></Route>
</Routes>
</BrowserRouter>

      <div>
        <Gauth/>
      </div>
      
    </>
  )
}

export default App
