import React, { useState } from "react";
import { auth,provider } from "../../../FirebaseConfig";
import { signInWithPopup } from "firebase/auth";
import "./Gauth.css"; 

export default function Gauth() {
 
  const handleLogin = async () => {
    await signInWithPopup(auth, provider)
      .then((user) => {
        console.log(user);
      })
  };

  return(
    <div className="wrapper">
            <button onClick={handleLogin}>Login with google</button>
    </div>
  );
}
