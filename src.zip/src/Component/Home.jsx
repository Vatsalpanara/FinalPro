import { onAuthStateChanged } from 'firebase/auth';
import React, { useEffect, useState } from 'react'
import { auth,db } from '../../../FirebaseConfig';
import { getDoc, doc, collection, updateDoc, deleteDoc, addDoc, getDocs } from 'firebase/firestore';
import '../App.css'

function Dashbord() {

    const [user, setUser]= useState("");
    const [email, setEmail]= useState("");
    const [password, setPassword]= useState("");

    const [record,setrecord] = useState([])
    const [ editIndex,setEditIdex] =useState(null)

    useEffect(() =>{
        onAuthStateChanged(auth,(currentUser) =>{
            if (currentUser){
                console.log(currentUser);
                setUser(currentUser.uid)
            }else{
                setUser("guest")
            }
        })
    },[])

    useEffect(() =>{
        fetchUser()
        fetchData()
    },[user])

    const fetchUser = async()=>{
        if(user){
            let data = await getDoc(doc(db, "user",user))
            console.log(data.data());   
        }
    }

    const fetchData = async () =>{
        let data = await getDocs(collection(db, "users"))
        console.log(data);
        let newData = data.docs.map((item) =>({docId: item.id, ...item.data()}))
        console.log(newData);
        setrecord(newData) 
    }

    const addData =async()=>{
        if(editIndex == null){
            await addDoc(collection(db,"users"),{
                email,password
            })
        }else{
            await updateDoc(doc(db,"users", editIndex),{email,password})
        }
                fetchData()
                setEditIdex(null)
                setEmail("")
                setPassword("")

    }

    const deleteData = async (docId) =>{
        await deleteDoc(doc(db,"users",docId));
        let deleteRecord = record.filter((item)=>item.docId != docId);
        setrecord(deleteRecord)
    }

    const editData =(docId) =>{
        let singleData = record.find((item)=> item.docId == docId);
        setEmail(singleData.email)
        setPassword(singleData.password)
        setEditIdex(docId)
    }
  return (
    
    <div class="wrapper">
    <h1>Dashborrd</h1>
    <input type="text" placeholder='email' value={email} onChange={(e) =>setEmail(e.target.value)} />
    <input type="text" placeholder='password' value={password} onChange={(e) =>setPassword(e.target.value)} />
    <button onClick={addData}>{editIndex == null ? "Add" :"Update"}</button>

    {
      record &&
      record.map((e, i) => {
        return (
          <ul key={i}>
            <li >{e.email}</li>
            <li >{e.password}</li>
            <button className='a1'  onClick={() => editData(e.docId)}>Edit</button><button className='a2'  onClick={() => deleteData(e.docId)}>Delete</button>
          </ul>
        );
      })
    
    }
    </div>
  )
}

export default Dashbord