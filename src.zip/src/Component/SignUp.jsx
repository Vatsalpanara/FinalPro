import { createUserWithEmailAndPassword } from 'firebase/auth'
import React, { useEffect, useState } from 'react'
import { auth,db } from '../../../FirebaseConfig'
import { addDoc, collection, doc, setDoc } from 'firebase/firestore'
import '../App.css'

export default function SignUp() {
    

    const [city,setCity]=useState("")
    const [email,setEmail]=useState("")
    const [password,setPassword]=useState("")

    const handleAdd =async ()=>{
        await createUserWithEmailAndPassword(auth,email,password)
        .then(data=>{
            console.log(data);
            setDoc(doc(db,"users",data.user.uid),{
                email,password
            })
            console.log("data added");  
            
        })
        await addDoc
        (collectionlection(db,"users"),{
            email,password
        }).then(() => {
            console.log(data);
        })
    }

  return (
    <div class="wrapper">
        <h1>SignUp</h1>
        <input type="text" placeholder='email' onChange={(e)=>setEmail(e.target.value)} /><br/><br/>
        <input type="text" placeholder='password' onChange={(e)=>setPassword(e.target.value)} /><br/><br/>
        <button onClick={handleAdd} >Add</button><br/><br/>
        <p><link to="/"/>signup</p>
    </div>
  )
}
